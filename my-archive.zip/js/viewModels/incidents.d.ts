declare class IncidentsViewModel {
    constructor();
    connected(): void;
    disconnected(): void;
    transitionCompleted(): void;
}
export = IncidentsViewModel;
