declare class AboutViewModel {
    constructor();
    connected(): void;
    disconnected(): void;
    transitionCompleted(): void;
}
export = AboutViewModel;
