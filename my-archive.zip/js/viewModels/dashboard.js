define(["require", "exports", "../accUtils", "knockout", "ojs/ojmutablearraydataprovider", "text!../store_data.json", "ojs/ojresponsiveutils", "ojs/ojresponsiveknockoututils", "ojs/ojhtmlutils", "ojs/ojselectsingle", "ojs/ojlabel", "ojs/ojchart", "ojs/ojlistview", "ojs/ojmodule-element"], function (require, exports, AccUtils, ko, MutableArrayDataProvider, storeData, ResponsiveUtils, ResponsiveKnockoutUtils, HtmlUtils) {
    "use strict";
    class DashboardViewModel {
        constructor() {
            this.val = ko.observable("pie");
            this.chartTypes = [
                { value: "pie", label: "Pie" },
                { value: "bar", label: "Bar" },
            ];
            this.chartData = [
                { "id": 0, "series": "Baseball", "group": "Group A", "value": 42 },
                { "id": 1, "series": "Baseball", "group": "Group B", "value": 34 },
                { "id": 2, "series": "Bicycling", "group": "Group A", "value": 55 },
                { "id": 3, "series": "Bicycling", "group": "Group B", "value": 30 },
                { "id": 4, "series": "Skiing", "group": "Group A", "value": 36 },
                { "id": 5, "series": "Skiing", "group": "Group B", "value": 50 },
                { "id": 6, "series": "Soccer", "group": "Group A", "value": 22 },
                { "id": 7, "series": "Soccer", "group": "Group B", "value": 46 }
            ];
            const lg_xl_view = '<h3 id="activityItemsHeader">Activity Items</h3>' +
                '<oj-list-view style="font-size: 18px" aria-labelledby="activityItemsHeader">' +
                "<ul>" +
                "<li>" +
                '<div class="oj-flex-item">' +
                "<p>SureCatch Baseball Glove</p>" +
                "<p>Western R16 Helmet</p>" +
                "<p>Western C1 Helmet</p>" +
                "<p>Western Bat</p>" +
                "</div>" +
                "</li>" +
                "<li>" +
                '<div class="oj-flex-item">' +
                "<p>Air-Lift Tire Pump</p>" +
                "<p>Intact Bike Helmet</p>" +
                "<p>Nimbus Bike Tire</p>" +
                "<p>Refill Water Bottle</p>" +
                "<p>Swift Boys 21 Speed</p>" +
                "</div>" +
                "</li>" +
                "</ul>" +
                "</oj-list-view>";
            const sm_md_view = '<div id="sm_md" style="background-color:lightcyan; padding: 10px; font-size: 10px">' +
                '<h3 id="activityDetailsHeader">Activity Details</h3>' +
                '<oj-list-view style="font-size: 18px" aria-labelledby="activityDetailsHeader">' +
                "<ul>" +
                "<li>" +
                '<div class="oj-flex-item">' +
                "<p>SureCatch Baseball Glove</p>" +
                "<p>Western R16 Helmet</p>" +
                "<p>Western C1 Helmet</p>" +
                "<p>Western Bat</p>" +
                "</div>" +
                "</li>" +
                "</ul>" +
                "</oj-list-view>" +
                "</div>";
            this.chartTypesDP = new MutableArrayDataProvider(this.chartTypes, {
                keyAttributes: "value",
            });
            this.chartDataProvider = new MutableArrayDataProvider(this.chartData, {
                keyAttributes: "id"
            });
            this.activityDataProvider = new MutableArrayDataProvider(JSON.parse(storeData), {
                keyAttributes: "id",
            });
            const lgQuery = ResponsiveUtils.getFrameworkQuery(ResponsiveUtils.FRAMEWORK_QUERY_KEY.LG_UP);
            this.large = ResponsiveKnockoutUtils.createMediaQueryObservable(lgQuery);
            this.moduleConfig = ko.pureComputed(() => {
                let viewNodes = HtmlUtils.stringToNodeArray(this.large() ? lg_xl_view : sm_md_view);
                return { view: viewNodes };
            });
        }
        connected() {
            AccUtils.announce("Dashboard page loaded.");
            document.title = "Dashboard";
        }
        disconnected() {
        }
        transitionCompleted() {
        }
    }
    return DashboardViewModel;
});
//# sourceMappingURL=dashboard.js.map