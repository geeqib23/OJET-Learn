/// <reference types="ojmutablearraydataprovider" />
import * as ko from "knockout";
import MutableArrayDataProvider = require("ojs/ojmutablearraydataprovider");
import "ojs/ojselectsingle";
import "ojs/ojlabel";
import "ojs/ojchart";
import "ojs/ojlistview";
import "ojs/ojmodule-element";
declare type ChartType = {
    value: string;
    label: string;
};
declare type Activity = {
    id: number;
};
declare class DashboardViewModel {
    chartTypes: Array<Object>;
    chartTypesDP: MutableArrayDataProvider<ChartType["value"], ChartType>;
    val: ko.Observable<string>;
    chartDataProvider: MutableArrayDataProvider<string, {}>;
    chartData: Array<Object>;
    activityDataProvider: MutableArrayDataProvider<Activity["id"], Activity>;
    large: ko.Observable<Boolean>;
    moduleConfig: ko.PureComputed<any>;
    constructor();
    connected(): void;
    disconnected(): void;
    transitionCompleted(): void;
}
export = DashboardViewModel;
