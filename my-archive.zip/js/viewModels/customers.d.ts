declare class CustomersViewModel {
    constructor();
    connected(): void;
    disconnected(): void;
    transitionCompleted(): void;
}
export = CustomersViewModel;
