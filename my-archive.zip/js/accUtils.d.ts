export declare function announce(message: string, manner?: string): void;
